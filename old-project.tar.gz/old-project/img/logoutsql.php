﻿<?php

	echo "Logout efetuado com sucesso!";
	
	echo '<meta http-equiv="refresh" content="3;URL=index.php" />';
	
?>